/***************************************************************************//**
*   @file    ad7124_regs.c
*   @brief   AD7124 register file.
*   	     Devices: AD7124-4, AD7124-8
*
********************************************************************************
* Copyright 2015-2019(c) Analog Devices, Inc.
*
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*  - Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
*  - Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in
*    the documentation and/or other materials provided with the
*    distribution.
*  - Neither the name of Analog Devices, Inc. nor the names of its
*    contributors may be used to endorse or promote products derived
*    from this software without specific prior written permission.
*  - The use of this software may or may not infringe the patent rights
*    of one or more patent holders.  This license does not release you
*    from the requirement that you obtain separate licenses from these
*    patent holders to use this software.
*  - Use of the software either in source or binary form, must be run
*    on or directly connected to an Analog Devices Inc. component.
*
* THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT, MERCHANTABILITY
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL ANALOG DEVICES BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* INTELLECTUAL PROPERTY RIGHTS, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/


#include "ad7124_regs.h"

struct ad7124_st_reg ad7124_regs[AD7124_REG_NO] = {
	    {0x00, 0x00, 1, 2}, // Status
	    {0x01, 0x0700, 2, 1}, // ADC Control (Cont conv, internal ref always on, full power)
	    {0x02, 0x000000, 3, 2}, // Data
	    {0x03, 0x000044, 3, 1}, // IO_CTRL1: 500uA on AIN4 for cold junction
	    {0x04, 0x0000, 2, 1}, // IO_CTRL2 (default)
	    {0x05, 0x00, 1, 2}, // ID
	    {0x06, 0x000000, 3, 2}, // Error
	    {0x07, 0x000000, 3, 1}, // Error_En
	    {0x08, 0x00, 1, 2}, // Mclk count

	    // Channel Map Registers
	    {0x09, 0x8001, 2, 1}, // CH0: TC1 (AIN0+/AIN1-), Setup 0, Enabled
	    {0x0A, 0x8203, 2, 1}, // CH1: TC2 (AIN2+/AIN3-), Setup 0, Enabled
	    {0x0B, 0x8455, 2, 1}, // CH2: Cold Junction (AIN4+/AIN5-), Setup 1, Enabled
	    {0x0C, 0x0001, 2, 1}, // CH3 (disabled)
	    {0x0D, 0x0001, 2, 1}, // CH4 (disabled)
	    {0x0E, 0x0001, 2, 1}, // CH5 (disabled)
	    {0x0F, 0x0001, 2, 1}, // CH6 (disabled)
	    {0x10, 0x0001, 2, 1}, // CH7 (disabled)
	    {0x11, 0x0001, 2, 1}, // CH8 (disabled)
	    {0x12, 0x0001, 2, 1}, // CH9 (disabled)
	    {0x13, 0x0001, 2, 1}, // CH10 (disabled)
	    {0x14, 0x0001, 2, 1}, // CH11 (disabled)
	    {0x15, 0x0001, 2, 1}, // CH12 (disabled)
	    {0x16, 0x0001, 2, 1}, // CH13 (disabled)
	    {0x17, 0x0001, 2, 1}, // CH14 (disabled)
	    {0x18, 0x0001, 2, 1}, // CH15 (disabled)

	    // Setup Configs
	    {0x19, 0x0A60, 2, 1}, // CFG0: Bipolar, Gain 128, Internal Ref, Buffer enabled
	    {0x1A, 0x0A10, 2, 1}, // CFG1: Bipolar, Gain 1, External Ref (REFIN1), Buffer enabled
	    {0x1B, 0x0860, 2, 1}, // CFG2 (default)
	    {0x1C, 0x0860, 2, 1}, // CFG3 (default)
	    {0x1D, 0x0860, 2, 1}, // CFG4
	    {0x1E, 0x0860, 2, 1}, // CFG5
	    {0x1F, 0x0860, 2, 1}, // CFG6
	    {0x20, 0x0860, 2, 1}, // CFG7

	    // Filters - Lower FS for better noise rejection
	    {0x21, 0x060320, 3, 1}, // Filter 0: Sinc4, FS = 800 (25SPS) for TCs
	    {0x22, 0x060180, 3, 1}, // Filter 1: Sinc4, FS = 384 (50SPS) for cold junction
	    {0x23, 0x060180, 3, 1}, // Filter 2 (default)
	    {0x24, 0x060180, 3, 1}, // Filter 3
	    {0x25, 0x060180, 3, 1}, // Filter 4
	    {0x26, 0x060180, 3, 1}, // Filter 5
	    {0x27, 0x060180, 3, 1}, // Filter 6
	    {0x28, 0x060180, 3, 1}, // Filter 7

	    // Offsets (default)
	    {0x29, 0x800000, 3, 1}, // Offset0
	    {0x2A, 0x800000, 3, 1},
	    {0x2B, 0x800000, 3, 1},
	    {0x2C, 0x800000, 3, 1},
	    {0x2D, 0x800000, 3, 1},
	    {0x2E, 0x800000, 3, 1},
	    {0x2F, 0x800000, 3, 1},
	    {0x30, 0x800000, 3, 1},

	    // Gains (default)
	    {0x31, 0x500000, 3, 1},
	    {0x32, 0x500000, 3, 1},
	    {0x33, 0x500000, 3, 1},
	    {0x34, 0x500000, 3, 1},
	    {0x35, 0x500000, 3, 1},
	    {0x36, 0x500000, 3, 1},
	    {0x37, 0x500000, 3, 1},
	    {0x38, 0x500000, 3, 1},
	};
